package model;
public class produk {
    private String idproduk;
    private String namaproduk;
    private int hargaproduk;
    private int stokproduk;
    
    public String getIdProduk(){
        return idproduk;
    }
    public void setIdProduk(String idproduk){
        this.idproduk = idproduk;
    }
    public String getNamaProduk(){
        return namaproduk;
    }
    public void setNamaProduk(String namaproduk){
        this.namaproduk = namaproduk;
    }
    public double getHargaProduk(){
        return hargaproduk;
    } 
    public void setHargaProduk(int hargaproduk){
        this.hargaproduk = hargaproduk;
    }
    public double getStokProduk(){
        return stokproduk;
    }
    public void setStok (int stokproduk){
        this.stokproduk = stokproduk;
    }
    
}

